require 'test_helper'

class FavoritTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
